SWR] Données récupérées pour la clé: supabase:chasseurs 
(43) [{…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}]
useSupabaseFetch.ts:58 [SWR] Données récupérées pour la clé: supabase:chasseurs 
(43) [{…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}]
useSupabaseFetch.ts:58 [SWR] Données récupérées pour la clé: supabase:noyaux 
(12) [{…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}]
useSupabaseFetch.ts:58 [SWR] Données récupérées pour la clé: supabase:chasseurs 
(43) [{…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}]
useSupabaseFetch.ts:58 [SWR] Données récupérées pour la clé: supabase:noyaux 
(12) [{…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}]
imageCache.ts:85 [IndexedDB] Image mise en cache: https://todwuewxymmybbunbclz.supabase.co/storage/v1/object/public/elements//Lumiere_element.webp
imageCache.ts:116 [IndexedDB] Image téléchargée et mise en cache: https://todwuewxymmybbunbclz.supabase.co/storage/v1/object/public/elements//Lumiere_element.webp
LazyImage.tsx:67 [LazyImage] Image chargée: https://todwuewxymmybbunbclz.supabase.co/storage/v1/object/public/elements//Lumiere_element.webp
useSupabaseFetch.ts:58 [SWR] Données récupérées pour la clé: supabase:chasseurs 
(43) [{…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}]
useSupabaseFetch.ts:58 [SWR] Données récupérées pour la clé: supabase:noyaux 
(12) [{…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}]
useSupabaseFetch.ts:58 [SWR] Données récupérées pour la clé: supabase:ombres 
(10) [{…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}]
useSupabaseFetch.ts:58 [SWR] Données récupérées pour la clé: supabase:chasseurs 
(43) [{…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}]
useSupabaseFetch.ts:58 [SWR] Données récupérées pour la clé: supabase:noyaux 
(12) [{…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}]
useSupabaseFetch.ts:58 [SWR] Données récupérées pour la clé: supabase:ombres 
(10) [{…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}]
imageCache.ts:85 [IndexedDB] Image mise en cache: https://todwuewxymmybbunbclz.supabase.co/storage/v1/object/public/elements//Eau_element.webp
imageCache.ts:116 [IndexedDB] Image téléchargée et mise en cache: https://todwuewxymmybbunbclz.supabase.co/storage/v1/object/public/elements//Eau_element.webp
LazyImage.tsx:67 [LazyImage] Image chargée: https://todwuewxymmybbunbclz.supabase.co/storage/v1/object/public/elements//Eau_element.webp
useSupabaseFetch.ts:58 [SWR] Données récupérées pour la clé: supabase:chasseurs 
(43) [{…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}]
useSupabaseFetch.ts:58 [SWR] Données récupérées pour la clé: supabase:noyaux 
(12) [{…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}]
useSupabaseFetch.ts:58 [SWR] Données récupérées pour la clé: supabase:ombres 
(10) [{…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}]
useSupabaseFetch.ts:58 [SWR] Données récupérées pour la clé: supabase:sets_bonus 
(60) [{…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}]
imageCache.ts:85 [IndexedDB] Image mise en cache: https://todwuewxymmybbunbclz.supabase.co/storage/v1/object/public/elements//Vent_element.webp
imageCache.ts:116 [IndexedDB] Image téléchargée et mise en cache: https://todwuewxymmybbunbclz.supabase.co/storage/v1/object/public/elements//Vent_element.webp
LazyImage.tsx:67 [LazyImage] Image chargée: https://todwuewxymmybbunbclz.supabase.co/storage/v1/object/public/elements//Vent_element.webp
useSupabaseFetch.ts:58 [SWR] Données récupérées pour la clé: supabase:chasseurs 
(43) [{…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}]
useSupabaseFetch.ts:58 [SWR] Données récupérées pour la clé: supabase:noyaux 
(12) [{…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}]
useSupabaseFetch.ts:58 [SWR] Données récupérées pour la clé: supabase:ombres 
(10) [{…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}]
useSupabaseFetch.ts:58 [SWR] Données récupérées pour la clé: supabase:sets_bonus 
(60) [{…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}]
imageCache.ts:85 [IndexedDB] Image mise en cache: https://todwuewxymmybbunbclz.supabase.co/storage/v1/object/public/elements//Feu_element.webp
imageCache.ts:116 [IndexedDB] Image téléchargée et mise en cache: https://todwuewxymmybbunbclz.supabase.co/storage/v1/object/public/elements//Feu_element.webp
LazyImage.tsx:67 [LazyImage] Image chargée: https://todwuewxymmybbunbclz.supabase.co/storage/v1/object/public/elements//Feu_element.webp
imageCache.ts:85 [IndexedDB] Image mise en cache: https://todwuewxymmybbunbclz.supabase.co/storage/v1/object/public/hunter-portrait//SungJinWoo_Jeju_Portrait.png
imageCache.ts:116 [IndexedDB] Image téléchargée et mise en cache: https://todwuewxymmybbunbclz.supabase.co/storage/v1/object/public/hunter-portrait//SungJinWoo_Jeju_Portrait.png
LazyImage.tsx:67 [LazyImage] Image chargée: https://todwuewxymmybbunbclz.supabase.co/storage/v1/object/public/hunter-portrait//SungJinWoo_Jeju_Portrait.png
useSupabaseFetch.ts:58 [SWR] Données récupérées pour la clé: supabase:chasseurs 
(43) [{…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}]
useSupabaseFetch.ts:58 [SWR] Données récupérées pour la clé: supabase:noyaux 
(12) [{…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}]
useSupabaseFetch.ts:58 [SWR] Données récupérées pour la clé: supabase:ombres 
(10) [{…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}]
useSupabaseFetch.ts:58 [SWR] Données récupérées pour la clé: supabase:sets_bonus 
(60) [{…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}, {…}]
imageCache.ts:85 [IndexedDB] Image mise en cache: https://todwuewxymmybbunbclz.supabase.co/storage/v1/object/public/elements//Tenebre_element.webp
imageCache.ts:116 [IndexedDB] Image téléchargée et mise en cache: https://todwuewxymmybbunbclz.supabase.co/storage/v1/object/public/elements//Tenebre_element.webp
LazyImage.tsx:67 [LazyImage] Image chargée: https://todwuewxymmybbunbclz.supabase.co/storage/v1/object/public/elements//Tenebre_element.webp
imageCache.ts:85 [IndexedDB] Image mise en cache: https://todwuewxymmybbunbclz.supabase.co/storage/v1/object/public/artefacts/infamie_chaotique/Boucles_du_stigmate_chaotique.webp
imageCache.ts:116 [IndexedDB] Image téléchargée et mise en cache: https://todwuewxymmybbunbclz.supabase.co/storage/v1/object/public/artefacts/infamie_chaotique/Boucles_du_stigmate_chaotique.webp
imageCache.ts:85 [IndexedDB] Image mise en cache: https://todwuewxymmybbunbclz.supabase.co/storage/v1/object/public/artefacts/instinct_destructeur/Bague_de_linstinct_destructeur.webp
imageCache.ts:116 [IndexedDB] Image téléchargée et mise en cache: https://todwuewxymmybbunbclz.supabase.co/storage/v1/object/public/artefacts/instinct_destructeur/Bague_de_linstinct_destructeur.webp
imageCache.ts:85 [IndexedDB] Image mise en cache: https://todwuewxymmybbunbclz.supabase.co/storage/v1/object/public/artefacts/infamie_chaotique/Bracelet_du_stigmate_chaotique.webp
imageCache.ts:116 [IndexedDB] Image téléchargée et mise en cache: https://todwuewxymmybbunbclz.supabase.co/storage/v1/object/public/artefacts/infamie_chaotique/Bracelet_du_stigmate_chaotique.webp
imageCache.ts:85 [IndexedDB] Image mise en cache: https://todwuewxymmybbunbclz.supabase.co/storage/v1/object/public/artefacts/infamie_chaotique/Bague_du_stigmate_chaotique.webp
imageCache.ts:116 [IndexedDB] Image téléchargée et mise en cache: https://todwuewxymmybbunbclz.supabase.co/storage/v1/object/public/artefacts/infamie_chaotique/Bague_du_stigmate_chaotique.webp
imageCache.ts:85 [IndexedDB] Image mise en cache: https://todwuewxymmybbunbclz.supabase.co/storage/v1/object/public/artefacts/voeu_chaotique/Bracelet_de_lorigine_chaotique.webp
imageCache.ts:116 [IndexedDB] Image téléchargée et mise en cache: https://todwuewxymmybbunbclz.supabase.co/storage/v1/object/public/artefacts/voeu_chaotique/Bracelet_de_lorigine_chaotique.webp
imageCache.ts:85 [IndexedDB] Image mise en cache: https://todwuewxymmybbunbclz.supabase.co/storage/v1/object/public/artefacts/voeu_chaotique/Boucles_de_lorigine_chaotique.webp
imageCache.ts:116 [IndexedDB] Image téléchargée et mise en cache: https://todwuewxymmybbunbclz.supabase.co/storage/v1/object/public/artefacts/voeu_chaotique/Boucles_de_lorigine_chaotique.webp
imageCache.ts:85 [IndexedDB] Image mise en cache: https://todwuewxymmybbunbclz.supabase.co/storage/v1/object/public/artefacts/infamie_chaotique/Armures_du_stigmate_chaotique.webp
imageCache.ts:116 [IndexedDB] Image téléchargée et mise en cache: https://todwuewxymmybbunbclz.supabase.co/storage/v1/object/public/artefacts/infamie_chaotique/Armures_du_stigmate_chaotique.webp
imageCache.ts:85 [IndexedDB] Image mise en cache: https://todwuewxymmybbunbclz.supabase.co/storage/v1/object/public/artefacts/tenacite/Gants_en_cuir_rigide.webp
imageCache.ts:116 [IndexedDB] Image téléchargée et mise en cache: https://todwuewxymmybbunbclz.supabase.co/storage/v1/object/public/artefacts/tenacite/Gants_en_cuir_rigide.webp
imageCache.ts:85 [IndexedDB] Image mise en cache: https://todwuewxymmybbunbclz.supabase.co/storage/v1/object/public/artefacts/instinct_destructeur/Collier_de_linstinct_destructeur.webp
imageCache.ts:116 [IndexedDB] Image téléchargée et mise en cache: https://todwuewxymmybbunbclz.supabase.co/storage/v1/object/public/artefacts/instinct_destructeur/Collier_de_linstinct_destructeur.webp
imageCache.ts:85 [IndexedDB] Image mise en cache: https://todwuewxymmybbunbclz.supabase.co/storage/v1/object/public/artefacts/instinct_destructeur/Boucles_de_linstinct_destructeur.webp
imageCache.ts:116 [IndexedDB] Image téléchargée et mise en cache: https://todwuewxymmybbunbclz.supabase.co/storage/v1/object/public/artefacts/instinct_destructeur/Boucles_de_linstinct_destructeur.webp
imageCache.ts:85 [IndexedDB] Image mise en cache: https://todwuewxymmybbunbclz.supabase.co/storage/v1/object/public/artefacts/voeu_chaotique/Collier_de_lorigine_chaotique.webp
imageCache.ts:116 [IndexedDB] Image téléchargée et mise en cache: https://todwuewxymmybbunbclz.supabase.co/storage/v1/object/public/artefacts/voeu_chaotique/Collier_de_lorigine_chaotique.webp
imageCache.ts:85 [IndexedDB] Image mise en cache: https://todwuewxymmybbunbclz.supabase.co/storage/v1/object/public/artefacts/voeu_chaotique/Gants_de_lorigine_chaotique.webp
﻿