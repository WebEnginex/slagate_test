// 📦 Export principal pour SWR
export {
  useSupabaseFetch,
  useSupabasePaginated,
  useSupabaseSingle,
  useSupabaseRealtime,
  cacheKeys,
} from './useSupabaseFetch';
export { default } from './useSupabaseFetch';
