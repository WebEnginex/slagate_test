export const lastModifiedDates: Record<string, string> = {
    index: "11 Mai 2025 | 01:23",
    tierList: "24 Septembre 2025 | 7:00",
    builds: "24 Septembre 2025 | 12:00",
    atelier: "11 Mai 2025 | 01:23",
    promoCodes: "22 Septembre 2025 | 16:52",
    creators: "11 Mai 2025 | 01:23",
    ennio: "11 Mai 2025 | 01:23",
    bdg: "11 Mai 2025 | 01:23",
    vulcan: "11 Mai 2025 | 01:23",
    baran: "11 Mai 2025 | 01:23",
    deimos: "11 Mai 2025 | 01:23",
  };