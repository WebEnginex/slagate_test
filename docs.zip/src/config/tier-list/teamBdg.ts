export const teamBdgTiers = {
  "Liste Boss : Giant Statue": [
    {
      id: 1,
      name: "Giant Statue - Feu",
      hunters: [49, 10, 11, 39, 24, 6], 
    },
    {
      id: 2,
      name: "Giant Statue - Ténèbres & Vent",
      hunters: [48, 19, 5, 44, 47, 50], 
    },
  ],
  A: [],
  B: [],
  C: [],
  D: [],
};